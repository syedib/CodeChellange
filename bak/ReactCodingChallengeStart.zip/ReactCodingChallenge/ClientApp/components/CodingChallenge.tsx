import * as React from 'react';
import { Link, RouteComponentProps } from 'react-router-dom';
import { connect } from 'react-redux';
import { ApplicationState }  from '../store';
import * as CodingChallengeState from '../store/CodingChallenge';

// At runtime, Redux will merge together...
type CodingChallengeProps =
    CodingChallengeState.CodingChallengeState         // ... state we've requested from the Redux store
    & typeof CodingChallengeState.actionCreators      // ... plus action creators we've requested
    & RouteComponentProps<{}>;  

class CodingChallenge extends React.Component<CodingChallengeProps, {}> {
    componentWillMount() {
        // This method runs when the component is first added to the page
        let input: CodingChallengeState.CodingChallengeInput = this.props.input;
        this.props.requestCodingChallenge({ ...input }, true);
    }

    public render() {
        return <div>
            <h1>Coding challenge</h1>
            <p>This component demonstrates a datadriven, dynamic SPA talking to a backend REST API</p>
            {this.renderForm()}
        </div>;
    }

    private renderForm() {
        const { codingChallenge, input, isLoading } = this.props;
        if (codingChallenge === undefined) {
            return <div>Images:<br />No coding challenge defined...</div>;
        }
        // TODO: make imageCount, crew productivity and crew size variable
        return <div>Images:<br />
            {input.imageCount} images, {codingChallenge.minutes} minutes work<br />
            Crew:<br />
            {input.crewCapacity.map((capacity, index) =>
                <div key={index}>
                    Crew member {index + 1}, speed: {capacity} minutes per image, images handled: {codingChallenge.crewProductivity[index]}
                </div>
            )}
            <br />
            {isLoading && <span>Loading...</span>}
        </div>;
    }
}

export default connect(
    (state: ApplicationState) => state.codingChallenge, // Selects which state properties are merged into the component's props
    CodingChallengeState.actionCreators                 // Selects which action creators are merged into the component's props
)(CodingChallenge as any) as typeof CodingChallenge;
